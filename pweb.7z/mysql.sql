CREATE DATABASE ocorrencia_criminal;
USE ocorrencia_criminal;

CREATE TABLE ocorrencia(
    oc_id int primary key not null auto_increment,
    oc_nome_vitima varchar(100),
    oc_tipo varchar(60),
    oc_descricao text,
    oc_data_hora varchar(45),
    oc_midia text,
    oc_local varchar(100)    
);

