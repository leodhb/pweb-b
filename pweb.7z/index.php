<?php  
  require_once "controller/ocorrenciaController.php";
  
  $ocorrenciaController = new OcorrenciaController();

  if(isset($_POST['acao'])){

  if($_POST['acao'] == 'postar'){
    $_POST['acao'] == 'a';

    $destino = 'img/' . $_FILES['arquivo']['name'];
    $arquivo_tmp = $_FILES['arquivo']['tmp_name'];
    move_uploaded_file($arquivo_tmp, $destino);

    $ocorrenciaController->inserir($_POST['nome'],$_POST['tipo'],$_POST['local'],$_POST['dataehora'],$_FILES['arquivo']['name'], $_POST['descricao']);
    header("Location: index.php");
    exit;
  }
}

  include_once "components/header.php";
	include_once "components/navbar.php";

?>
	<div class="header-bugfix"></div>

	<div style="display: block; margin-left: auto; margin-right: auto;height: 100%; width: 60rem;">



    <div class="card-post">

        <h4 class="card-title ml-1 title">Adicionar nova ocorrência</h4>
        <div class="card-body" style="padding: 15px !important;">


        <form role="form" method="POST" enctype="multipart/form-data" action="index.php">
            <fieldset>
              <input type="hidden" name="acao" value="postar">         
              <div class="form-group">
                <label for="tipo" style="color: #ffb347">Informe seu nome completo:</label>
                <input type="text" name="nome" id="nome" class="form-control input-lg" placeholder="Ex.: Jailson Mendes" required>
              </div>
              <div class="form-group">
                  <label for="tipo" style="color: #ffb347">Informe o tipo da ocorrência:</label>
                  <select class="form-control input-lg" name="tipo" id="tipo" required>
                      <option value="furto">furto</option>
                      <option value="assassinato">assassinato</option>
                      <option value="sequestro">sequestro</option>
                      <option value="latrocínio">latrocínio</option>
                      <option value="impotunação sexual">impotunação sexual</option>
                      <option value="assédio sexual">assédio sexual</option>
                      <option value="assédio moral">assédio moral</option>
                      <option value="furto">estupro</option>
                      <option value="violencia infantil">violencia infantil</option>
                      <option value="violencia doméstica">violencia doméstica</option>
                      <option value="abandono de incapaz">abandono de incapaz</option>
                      <option value="violencia contra animais">violencia contra animais</option>
                      <option value="abuso de incapaz">abuso de incapaz</option>
                      <option value="pedofilia">pedofilia</option>
                      <option value="agressão física">agressão física</option>
                      <option value="abuso de autoridade">abuso de autoridade</option>
                      <option value="trafico de drogas">trafico de drogas</option>
                      <option value="tiroteio">tiroteio</option>
                      <option value="atentado ao pudor">atentado ao pudor</option>
                      <option value="trafico de pessoas">trafico de pessoas</option>
                      <option value="trafico de armas">trafico de armas</option>
                      <option value="crime de homofobia">crime de homofobia</option>
                      <option value="crime de racismo">crime de racismo</option>
                      <option value="feminicidio">feminicidio</option>
                  </select>
                </div>
              <div class="form-group">
                  <label for="tipo" style="color: #ffb347">Informe a localidade da ocorrência:</label>
                  <select class="form-control input-lg" name="local" id="local" required>
                      <option value="alto do Cruzeiro">Alto do Cruzeiro</option>
                      <option value="Baixa Grande">Baixa Grande</option>
                      <option value="Baixao">Baixao</option>
                      <option value="Batingas">Batingas</option>
                      <option value="Boa Vista">Boa Vista</option>
                      <option value="Bom Sucesso">Bom Sucesso</option>
                      <option value="Brasilia">Brasilia</option>
                      <option value="Brasiliana">Brasiliana</option>
                      <option value="Cacimbas">Cacimbas</option>
                      <option value="Catitus">Catitus</option>
                      <option value="Canafistula">Canafistula</option>
                      <option value="Capitão-de-Fragata">Capitão-de-Fragata</option>
                      <option value="Cavaco">Cavaco</option>
                      <option value="Centro">Centro</option>
                      <option value="Distrito Industrial">Distrito Industrial</option>
                      <option value="Eldorado">Eldorado</option>
                      <option value="Guaribas">Guaribas</option>
                      <option value="Itapoã">Itapoã</option>
                      <option value="Jardim de Maria">Jardim de Maria</option>
                      <option value="Jardim Esperança">Jardim Esperança</option>
                      <option value="Jardim Tropical">Jardim Tropical</option>
                      <option value="Manoel Teles">Manoel Teles</option>
                      <option value="Massaranduba">Massaranduba</option>
                      <option value="Nova Esperança">Nova Esperança</option>
                      <option value="Novo Horizonte">Novo Horizonte</option>
                      <option value="Olho D'água dos Cazuzinhos">Olho D'água dos Cazuzinhos</option>
                      <option value="Ouro Preto">Ouro Preto</option>
                      <option value="Padre Antonio Lima">Padre Antonio Lima</option>
                      <option value="Planalto">Planalto</option>
                      <option value="Primavera">Primavera</option>
                      <option value="Rosa Cruz">Rosa Cruz</option>
                      <option value="Santa Edwiges">Santa Edwiges</option>
                      <option value="Santa Esmeralda">Santa Esmeralda</option>
                      <option value="São Luiz">São Luiz</option>
                      <option value="São Luiz II">São Luiz II</option>
                      <option value="Senador Arnon de Melo">Senador Arnon de Melo</option>
                      <option value="Senador Nilo Coelho">Senador Nilo Coelho</option>
                      <option value="Senador Teotônio Vilela">Senador Teotônio Vilela</option>
                      <option value="Verdes Campos">Verdes Campos</option>
                      <option value="Zélia Barbosa Rocha">Zélia Barbosa Rocha</option>
                  </select>
                </div>

                          <label for="tipo" style="color: #ffb347">Informe a data e a hora do ocorrido:</label>
                            <div class="form-group">
                                <div class='input-group date' id='datetimepicker1'>
                                    <input type='text' class="form-control input-lg" name="dataehora" id="dateehora"/>
                                    <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                            </div>
                        <script type="text/javascript">
                            $(function () {
                                $('#datetimepicker1').datetimepicker();
                            });
                        </script>


              <div class="form-group">
                <label for="tipo" style="color: #ffb347">Envie uma imagem referente ao acontecido</label>
                <input style="color: #ffb347" class="form-control input-lg" id="arquivo" name="arquivo" type="file" required/>
              </div>


              <div class="form-group">
                <label for="tipo" style="color: #ffb347">Descreva com mais detalhes a ocorrência</label>
                <input type="text" name="descricao" id="descricao" class="form-control input-lg" placeholder="Descrição">
              </div>
              <div>
                <input type="submit" class="btn btn-md btn-warning" style="width: 100%;" value="Enviar">
              </div>
                 
            </fieldset>
        </form> 
      </div>
    </div>
<h4 class="card-title ml-1 title" style="padding-left: 16rem">ÚLTIMAS FRESQUINHAS</h4>

<?php

    $posts = $ocorrenciaController->listar();
 	
  if(!empty($posts))
  {

 	foreach ($posts as $data){
?>
        <div class="card-post">
        <h4 class="card-title ml-1 title"><?php echo $data['oc_tipo']; ?> em <?php echo $data['oc_local']; ?></h4>
        
        <div class="card-body">
          <p class="card-text ml-1 card-footer">Enviado por: <?php echo $data['oc_nome_vitima']; ?></p><br>
        <p class="card-text ml-1 card-footer">Descrição do ocorrido: <?php echo $data['oc_descricao']; ?></p><br>
        
        <img style="margin-bottom: 20px;" class="card-img-top ml-1 featured" <?php  echo 'src="img/'.$data['oc_midia'].'"'?>><br>
        <p class="card-text ml-1 card-footer">Data: <?php echo $data['oc_data_hora']; ?></p><br>
      </div>
      </div>
  <?php
  }  
    }
  ?>
</div>


<?php  
include_once "components/footer.php";
?>