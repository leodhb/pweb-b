<?php

class OcorrenciaDAO {
	

	function inserir($nome, $tipo, $local, $dataehora, $midia, $descricao){
			$conn = new PDO(
			    'mysql:host=localhost;dbname=ocorrencia_criminal', 'root', ''
			);

			$stmt = $conn->prepare(
				    "INSERT INTO ocorrencia (oc_nome_vitima, oc_tipo, oc_local, oc_data_hora, oc_midia, oc_descricao) VALUES (?, ?, ?, ?, ?, ?);"
				);
				$stmt->execute([$nome, $tipo, $local, $dataehora, $midia, $descricao]);
		}

		function listar(){
			$conn = new PDO(
			    'mysql:host=localhost;dbname=ocorrencia_criminal', 'root', ''
			);
			$stmt = $conn->query("SELECT * FROM ocorrencia ORDER BY oc_id desc");
			$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
			$ocorrencias = array();

			foreach ($result as $ocor) {
				array_push($ocorrencias, $ocor);
			}
			
			return $ocorrencias;
			
		}

		function getOcorrenciaById($id){
			$conn = new PDO(
			    'mysql:host=localhost;dbname=ocorrencia_criminal', 'root', ''
			);
			$stmt = $conn->query("SELECT * FROM ocorrencia where oc_id= $id;");
			$result = $stmt->fetch(PDO::FETCH_OBJ);
			$ocorrencia = $result;
			return $ocorrencia;
			

		}
		
}