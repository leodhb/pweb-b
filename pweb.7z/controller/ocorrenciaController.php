<?php
require_once "DAO/ocorrenciaDAO.php";

class OcorrenciaController{
	public $ocorrenciaDAO;
	
	public function __construct(){
		$this->ocorrenciaDAO = new OcorrenciaDAO();
	}
	
	function inserir($nome, $tipo, $local, $dataehora, $midia, $descricao){
		return $this->ocorrenciaDAO->inserir($nome, $tipo, $local, $dataehora, $midia, $descricao);
	}
	
	function listar(){
		return $this->ocorrenciaDAO->listar();
	}
	
	function getOcorrenciaById($id){
		return $this->ocorrenciaDAO->getOcorrenciaById($id);
	}
}